package com.example.EmployeeManagementSystem.entity;

public interface EmployeeProjection {
        String getName();
        String getEmail();
        String getDepartmentName();
}

