package com.library.repository;

public class BookRepository {
    public void performRepositoryAction() {
        System.out.println("Repository action performed.");
    }
}
