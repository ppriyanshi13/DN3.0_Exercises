public class ECommerceSearch {
    
    // Inner Product class
    public static class Product {
        private String productId;
        private String productName;
        private String category;

        public Product(String productId, String productName, String category) {
            this.productId = productId;
            this.productName = productName;
            this.category = category;
        }

        public String getProductId() {
            return productId;
        }

        public String getProductName() {
            return productName;
        }

        public String getCategory() {
            return category;
        }

        @Override
        public String toString() {
            return "Product{" +
                    "productId='" + productId + '\'' +
                    ", productName='" + productName + '\'' +
                    ", category='" + category + '\'' +
                    '}';
        }
    }

    // Linear Search
    public static Product linearSearch(Product[] products, String productId) {
        for (Product product : products) {
            if (product.getProductId().equals(productId)) {
                return product;
            }
        }
        return null;
    }

    // Binary Search
    public static Product binarySearch(Product[] products, String productId) {
        int left = 0;
        int right = products.length - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            int comparison = products[mid].getProductId().compareTo(productId);
            if (comparison == 0) {
                return products[mid];
            } else if (comparison < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
    }

    // Helper method to sort products array by productId
    public static void sortProducts(Product[] products) {
        java.util.Arrays.sort(products, (p1, p2) -> p1.getProductId().compareTo(p2.getProductId()));
    }

    // Main method for testing
    public static void main(String[] args) {
        Product[] products = {
                new Product("102", "Smartphone", "Electronics"),
                new Product("101", "Laptop", "Electronics"),
                new Product("103", "Tablet", "Electronics")
        };

        // Linear Search
        System.out.println("Linear Search:");
        System.out.println(linearSearch(products, "101"));
        System.out.println(linearSearch(products, "104"));

        // Sort products array for binary search
        sortProducts(products);

        // Binary Search
        System.out.println("Binary Search:");
        System.out.println(binarySearch(products, "101"));
        System.out.println(binarySearch(products, "104"));
    }
}
