import java.util.ArrayList;
import java.util.List;

// Main class to implement the Observer Pattern
public class ObserverPatternExample {

    // Subject Interface
    public interface Stock {
        void registerObserver(Observer observer);
        void deregisterObserver(Observer observer);
        void notifyObservers();
    }

    // Concrete Subject
    public static class StockMarket implements Stock {
        private List<Observer> observers = new ArrayList<>();
        private String stockName;
        private double stockPrice;

        public StockMarket(String stockName, double stockPrice) {
            this.stockName = stockName;
            this.stockPrice = stockPrice;
        }

        public void setStockPrice(double stockPrice) {
            this.stockPrice = stockPrice;
            notifyObservers();
        }

        @Override
        public void registerObserver(Observer observer) {
            observers.add(observer);
        }

        @Override
        public void deregisterObserver(Observer observer) {
            observers.remove(observer);
        }

        @Override
        public void notifyObservers() {
            for (Observer observer : observers) {
                observer.update(stockName, stockPrice);
            }
        }
    }

    // Observer Interface
    public interface Observer {
        void update(String stockName, double stockPrice);
    }

    // Concrete Observer
    public static class Investor implements Observer {
        private String investorName;

        public Investor(String investorName) {
            this.investorName = investorName;
        }

        @Override
        public void update(String stockName, double stockPrice) {
            System.out.println(investorName + " notified. Stock: " + stockName + ", New Price: $" + stockPrice);
        }
    }

    // Test the Observer Pattern
    public static void main(String[] args) {
        // Create a stock market subject
        StockMarket stockMarket = new StockMarket("ABC Corp", 100.00);

        // Create observers
        Observer investor1 = new Investor("Alice");
        Observer investor2 = new Investor("Bob");

        // Register observers with the stock market
        stockMarket.registerObserver(investor1);
        stockMarket.registerObserver(investor2);

        // Change stock price and notify observers
        stockMarket.setStockPrice(105.00);
        stockMarket.setStockPrice(110.00);

        // Deregister an observer
        stockMarket.deregisterObserver(investor1);

        // Change stock price and notify remaining observers
        stockMarket.setStockPrice(115.00);
    }
}
