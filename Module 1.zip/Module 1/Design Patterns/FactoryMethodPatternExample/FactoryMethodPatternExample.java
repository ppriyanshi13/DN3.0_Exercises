public class FactoryMethodPatternExample {

    // Abstract Document class
    public abstract static class Document {
        public abstract void open();
        public abstract void close();
    }

    // Concrete WordDocument class
    public static class WordDocument extends Document {
        @Override
        public void open() {
            System.out.println("Opening Word document.");
        }

        @Override
        public void close() {
            System.out.println("Closing Word document.");
        }
    }

    // Concrete PdfDocument class
    public static class PdfDocument extends Document {
        @Override
        public void open() {
            System.out.println("Opening PDF document.");
        }

        @Override
        public void close() {
            System.out.println("Closing PDF document.");
        }
    }

    // Concrete ExcelDocument class
    public static class ExcelDocument extends Document {
        @Override
        public void open() {
            System.out.println("Opening Excel document.");
        }

        @Override
        public void close() {
            System.out.println("Closing Excel document.");
        }
    }

    // Abstract DocumentFactory class
    public abstract static class DocumentFactory {
        public abstract Document createDocument();
    }

    // Concrete WordDocumentFactory class
    public static class WordDocumentFactory extends DocumentFactory {
        @Override
        public Document createDocument() {
            return new WordDocument();
        }
    }

    // Concrete PdfDocumentFactory class
    public static class PdfDocumentFactory extends DocumentFactory {
        @Override
        public Document createDocument() {
            return new PdfDocument();
        }
    }

    // Concrete ExcelDocumentFactory class
    public static class ExcelDocumentFactory extends DocumentFactory {
        @Override
        public Document createDocument() {
            return new ExcelDocument();
        }
    }

    // Main method to test the Factory Method pattern
    public static void main(String[] args) {
        DocumentFactory wordFactory = new WordDocumentFactory();
        Document wordDoc = wordFactory.createDocument();
        wordDoc.open();
        wordDoc.close();

        DocumentFactory pdfFactory = new PdfDocumentFactory();
        Document pdfDoc = pdfFactory.createDocument();
        pdfDoc.open();
        pdfDoc.close();

        DocumentFactory excelFactory = new ExcelDocumentFactory();
        Document excelDoc = excelFactory.createDocument();
        excelDoc.open();
        excelDoc.close();
    }
}
